package com.fermine.umweltlite.example.entity;

import com.fermine.umweltlite.brain.capability.UmweltPipelineAttachment;
import com.fermine.umweltlite.brain.diagnostic.BrainDiagnosticScreen;
import com.fermine.umweltlite.brain.diagnostic.ICognitiveOrganism;
import com.fermine.umweltlite.brain.inter.IUmweltBrainPipeline;
import net.minecraft.client.Minecraft;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.PolarBear;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;

public class UmweltPolarBear extends PolarBear implements ICognitiveOrganism {

    // Synched parameters matching your simplified single-class engine registers
    private static final EntityDataAccessor<Float> DATA_STRESS = SynchedEntityData.defineId(UmweltPolarBear.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DATA_FATIGUE = SynchedEntityData.defineId(UmweltPolarBear.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<String> DATA_CURRENT_STAGE = SynchedEntityData.defineId(UmweltPolarBear.class, EntityDataSerializers.STRING);

    public UmweltPolarBear(EntityType<? extends PolarBear> entityType, Level level) {
        super(entityType, level);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.@NotNull Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_STRESS, 0.0F);
        builder.define(DATA_FATIGUE, 0.0F);
        builder.define(DATA_CURRENT_STAGE, "rest");
    }

    @Override
    protected void registerGoals() {
        // Kept blank so vanilla AI goals do not override or fight your custom cognitive pipeline actions!
    }

    @Override
    public @NotNull InteractionResult mobInteract(Player player, @NotNull InteractionHand hand) {
        ItemStack itemstack = player.getItemInHand(hand);

        if (itemstack.is(Items.RECOVERY_COMPASS)) {
            if (this.level().isClientSide()) {
                openDiagnosticGui();
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide());
        }

        return super.mobInteract(player, hand);
    }

    private void openDiagnosticGui() {
        Minecraft.getInstance().setScreen(new BrainDiagnosticScreen(this));
    }

    @Override
    public void tick() {
        super.tick();

        // Verify server-side loop processing running on the active world thread
        if (!this.level().isClientSide()) {
            if (this.hasData(UmweltPipelineAttachment.PIPELINE_ATTACHMENT.get())) {

                // 1. Grab the capability object straight as the generalized interface token
                IUmweltBrainPipeline brain = this.getData(UmweltPipelineAttachment.PIPELINE_ATTACHMENT.get());

                // 2. Drive the core logic and pipe registers safely into SynchedEntityData
                brain.tickBrainPipeline(this);

                this.entityData.set(DATA_STRESS, brain.getStress());
                this.entityData.set(DATA_FATIGUE, brain.getFatigue());
                this.entityData.set(DATA_CURRENT_STAGE, brain.getActiveStageName());
            }
        }
    }

    // --- Bridge Interface Implementations for Screen/Shader Layers ---

    @Override
    public float getSyncedPanic() {
        return this.entityData.get(DATA_STRESS); // Stress maps directly to panic diagnostics
    }

    @Override
    public float getSyncedExhaustion() {
        return this.entityData.get(DATA_FATIGUE); // Fatigue maps directly to exhaustion diagnostics
    }

    @Override
    public String getSyncedActiveAction() {
        return this.entityData.get(DATA_CURRENT_STAGE); // Displays the active structural loop stage
    }
}