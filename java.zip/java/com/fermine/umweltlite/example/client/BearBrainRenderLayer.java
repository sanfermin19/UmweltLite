package com.fermine.umweltlite.example.client;

import com.fermine.umweltlite.brain.capability.UmweltPipelineAttachment;
import com.fermine.umweltlite.brain.inter.IUmweltBrainPipeline;
import com.fermine.umweltlite.brain.impl.UmweltBrainEngine;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.model.PolarBearModel;
import net.minecraft.world.entity.animal.PolarBear;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FastColor;
import org.jetbrains.annotations.NotNull;

/**
 * A real-time rendering overlay layer that visually maps internal neurological register status
 * directly onto the entity body using color overlay shaders.
 */
public class BearBrainRenderLayer extends RenderLayer<PolarBear, PolarBearModel<PolarBear>> {

    // A glowing overlay texture map that matches the bear's eye/overlay layout
    private static final ResourceLocation BRAIN_GLOW_TEXTURE =
            ResourceLocation.fromNamespaceAndPath("umweltlite", "textures/entity/polarbear/bear_brain_glow.png");

    public BearBrainRenderLayer(RenderLayerParent<PolarBear, PolarBearModel<PolarBear>> parent) {
        super(parent);
    }

    @Override
    public void render(@NotNull PoseStack poseStack, @NotNull MultiBufferSource bufferSource, int packedLight,
                       @NotNull PolarBear bear, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {

        // Safety check: Ensure the server has synced the cognitive capability data attachment down to the client proxy
        if (bear.hasData(UmweltPipelineAttachment.PIPELINE_ATTACHMENT.get())) {
            IUmweltBrainPipeline pipeline = bear.getData(UmweltPipelineAttachment.PIPELINE_ATTACHMENT.get());

            if (pipeline instanceof UmweltBrainEngine engine) {
                // Pull out the exact core register variables
                float stress = engine.getStress();     // Maps to Red (Adrenaline/Anger indicator)
                float stimulus = engine.getStimulus(); // Maps to Green (Alertness/Perception indicator)
                float fatigue = engine.getFatigue();   // Maps to Blue (Exhaustion indicator)

                // Render an emissive translucent pass over the model using the register values mapped to an ARGB integer
                VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.eyes(BRAIN_GLOW_TEXTURE));

                // Convert the 0.0f - 1.0f floats into 0 - 255 integer ranges for the color packer
                int r = (int) (stress * 255.0F);
                int g = (int) (stimulus * 255.0F);
                int b = (int) (fatigue * 255.0F);
                int a = (int) (0.8F * 255.0F); // Alpha transparency weight of the cognitive aura

                // 1.21.1 Mojang mappings pack color values into a single ARGB integer using FastColor.ARGB32
                int packedColor = FastColor.ARGB32.color(a, r, g, b);

                // Fetch vanilla overlay coordinates (like when the entity flashes red from taking damage)
                int overlayCoords = net.minecraft.client.renderer.entity.LivingEntityRenderer.getOverlayCoords(bear, 0.0F);

                // Correct 1.21.1 renderToBuffer parameter structure:
                // renderToBuffer(PoseStack, VertexConsumer, packedLight, overlayCoords, packedColor)
                this.getParentModel().renderToBuffer(
                        poseStack,
                        vertexConsumer,
                        packedLight,
                        overlayCoords,
                        packedColor
                );
            }
        }
    }
}