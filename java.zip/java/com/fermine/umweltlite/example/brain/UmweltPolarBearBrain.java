package com.fermine.umweltlite.example.brain;

import com.fermine.umweltlite.brain.inter.IUmweltBrainPipeline;
import com.fermine.umweltlite.brain.inter.IUmweltAction;
import com.fermine.umweltlite.example.action.BearHuntingAction;
import com.fermine.umweltlite.example.action.BearRestAction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.Fox;
import net.minecraft.world.entity.animal.PolarBear;
import java.util.List;

/**
 * The production implementation of the 5-stage predatory cognitive pipeline.
 * Fully fulfills the IUmweltBrainPipeline interface contract.
 */
public class UmweltPolarBearBrain implements IUmweltBrainPipeline {

    // Internal register variables mapped directly to the visual shader overlays
    private float stress = 0.0F;
    private float stimulus = 0.0F;
    private float fatigue = 0.0F;

    // Track active executing strategy to handle clean state transitions
    private IUmweltAction activeAction = null;

    public UmweltPolarBearBrain() {
    }

    @Override
    public void tickBrainPipeline(PolarBear bear) {
        // --- STAGE 1: SENSORY PERCEPTION & APPRAISAL ---
        Mob preyTarget = null;
        List<Fox> nearbyFoxes = bear.level().getEntitiesOfClass(Fox.class, bear.getBoundingBox().inflate(16.0D));

        if (!nearbyFoxes.isEmpty()) {
            preyTarget = nearbyFoxes.getFirst();
        }

        // Adjust real-time registers based on sensory calculations
        if (preyTarget != null && preyTarget.isAlive()) {
            this.stimulus = 1.0F; // Turn on awareness overlay (Green)
            this.stress = Math.min(1.0F, this.stress + 0.02F); // Fill adrenaline (Red)
            this.fatigue = Math.min(1.0F, this.fatigue + 0.001F); // Exert muscle energy
        } else {
            this.stimulus = 0.0F;
            this.stress = Math.max(0.0F, this.stress - 0.01F); // Cooldown
            this.fatigue = Math.max(0.0F, this.fatigue - 0.002F); // Recover metabolic drain
        }

        // --- STAGE 2: EXECUTIVE ACTION CHOOSER ---
        IUmweltAction chosenAction;
        if (this.fatigue > 0.85F || preyTarget == null) {
            chosenAction = new BearRestAction(this.fatigue);
        } else {
            chosenAction = new BearHuntingAction(preyTarget, this.stress);
        }

        // --- STAGE 3: STATE TRANSITION HANDLING ---
        if (this.activeAction != null && !this.activeAction.getActionType().equals(chosenAction.getActionType())) {
            this.activeAction.stop(bear); // Cleanly put legs down and stop vanilla navigation overrides
        }

        this.activeAction = chosenAction;

        // --- STAGE 4 & 5: EXECUTION AND MOTOR OUTPUT ---
        this.activeAction.execute(bear);
    }

    @Override
    public void regulate(Mob host) {

    }

    // --- INTERFACE CONTRACT IMPLEMENTATIONS (GETTERS) ---

    @Override
    public float getStress() {
        return this.stress;
    }

    @Override
    public float getStimulus() {
        return this.stimulus;
    }

    @Override
    public float getFatigue() {
        return this.fatigue;
    }

    @Override
    public String getActiveStageName() {
        return this.activeAction != null ? this.activeAction.getActionType() : "IDLE";
    }

    // --- INTERFACE CONTRACT IMPLEMENTATIONS (NBT SERIALIZATION) ---

    @Override
    public CompoundTag serializePipeline() {
        CompoundTag tag = new CompoundTag();
        tag.putFloat("Stress", this.stress);
        tag.putFloat("Stimulus", this.stimulus);
        tag.putFloat("Fatigue", this.fatigue);
        return tag;
    }

    @Override
    public void deserializePipeline(CompoundTag tag) {
        if (tag.contains("Stress")) this.stress = tag.getFloat("Stress");
        if (tag.contains("Stimulus")) this.stimulus = tag.getFloat("Stimulus");
        if (tag.contains("Fatigue")) this.fatigue = tag.getFloat("Fatigue");
    }
}