package com.fermine.umweltlite.example.action;

import com.fermine.umweltlite.brain.inter.IUmweltAction;
import net.minecraft.world.entity.Mob;

public class BearRestAction implements IUmweltAction {
    private final float urgency;

    public BearRestAction(float urgency) {
        this.urgency = urgency;
    }

    @Override
    public String getActionType() { return "METABOLIC_REST"; }

    @Override
    public float getUrgency() { return this.urgency; }

    @Override
    public void execute(Mob host) {
        // Clear paths to conserve energy safely
        host.getNavigation().stop();
    }
}