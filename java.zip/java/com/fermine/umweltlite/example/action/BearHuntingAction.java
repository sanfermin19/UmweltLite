package com.fermine.umweltlite.example.action;

import com.fermine.umweltlite.brain.inter.IUmweltAction;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.PolarBear;

public class BearHuntingAction implements IUmweltAction {
    private final float urgency;
    private final Mob target;

    public BearHuntingAction(Mob target, float urgency) {
        this.target = target;
        this.urgency = urgency;
    }

    @Override
    public String getActionType() { return "SURVIVAL_HUNT"; }

    @Override
    public float getUrgency() { return this.urgency; }

    @Override
    public void execute(Mob host) {
        if (target == null || !target.isAlive()) return;

        // Lock navigation systems onto the prey
        host.getNavigation().moveTo(target, 1.4D);
        host.getLookControl().setLookAt(target, 30.0F, 30.0F);

        if (host.distanceToSqr(target) <= 3.0D) {
            host.doHurtTarget(target);
            if (host instanceof PolarBear bear) {
                bear.setStanding(true); // Fire signature visual animations
            }
        }
    }

    @Override
    public void stop(Mob host) {
        if (host instanceof PolarBear bear) {
            bear.setStanding(false);
        }
        host.getNavigation().stop();
    }
}