package com.fermine.umweltlite.api.entity.goal;

import com.fermine.umweltlite.api.engine.EmotionAPI;
import com.fermine.umweltlite.api.entity.IUmweltEntity;
import com.fermine.umweltlite.impl.engine.UmweltEngine;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;

public class UmweltAttackGoal extends MeleeAttackGoal {
    private final PathfinderMob mob;
    private final double baseSpeed;
    private int ticksSinceLastAction;

    public UmweltAttackGoal(PathfinderMob mob, double speed, boolean followingTargetEvenIfNotSeen) {
        super(mob, speed, followingTargetEvenIfNotSeen);
        this.mob = mob;
        this.baseSpeed = speed;
    }

    @Override
    public boolean canUse() {
        if (mob instanceof IUmweltEntity ue) {
            if (ue.getUmweltEngine().getEmotionalEngine().getEnergy() < 0.15f) {
                return false;
            }
        }
        return super.canUse();
    }

    @Override
    public boolean canContinueToUse() {
        if (mob instanceof IUmweltEntity ue) {
            UmweltEngine engine = ue.getUmweltEngine();
            if (engine.getEmotionalEngine().getEnergy() <= 0.02f) return false;
            if (engine.getEmotionalEngine().getArousal() < 0.1f) return false;
        }
        return super.canContinueToUse();
    }

    @Override
    public void start() {
        super.start();
        this.ticksSinceLastAction = 0; // Reset this when the goal starts!
    }

    @Override
    public void tick() {
        super.tick();
        this.ticksSinceLastAction++;

        if (mob instanceof IUmweltEntity ue) {
            UmweltEngine engine = ue.getUmweltEngine();
            float v = engine.getEmotionalEngine().getValence();
            float a = engine.getEmotionalEngine().getArousal();
            float currentEnergy = engine.getEmotionalEngine().getEnergy();

            if (a > 0.85f) {
                this.mob.setSpeed((float) (this.baseSpeed * 1.2f));
            } else {
                this.mob.setSpeed((float) this.baseSpeed);
            }

            if (v > 0.5f && this.ticksSinceLastAction % 40 == 0) {
                if (mob.onGround()) {
                    this.mob.getJumpControl().jump();
                    this.ticksSinceLastAction = 0; // Reset after jumping
                }
            }

            if (mob.getNavigation().isInProgress()) {
                EmotionAPI.setEnergy(engine, currentEnergy - 0.001f);
            }
        }
    }

    @Override
    public void stop() {
        super.stop();
        this.mob.setSpeed((float) this.baseSpeed);
    }
}