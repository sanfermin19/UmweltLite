package com.fermine.umweltlite.brain.diagnostic;

/**
 * Common bridge interface allowing client screens and layers to query synced neural metrics
 * from any custom organism regardless of its internal sub-lobe brain layout.
 */
public interface ICognitiveOrganism {
    float getSyncedPanic();
    float getSyncedExhaustion();
    String getSyncedActiveAction();
}