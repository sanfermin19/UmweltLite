package com.fermine.umweltlite.brain.inter;

import net.minecraft.world.entity.Mob;

public interface IUmweltAction {

    /**
     * @return The functional category of this action (e.g., "SURVIVAL", "METABOLIC", "SOCIAL", "IDLE").
     */
    String getActionType();

    /**
     * @return The weight or urgency score computed by the submitting component.
     */
    float getUrgency();

    /**
     * Executes the localized movement, navigation, or state changes on the mob body.
     */
    void execute(Mob host);

    /**
     * Called every tick while this action remains the dominant choice.
     * Returns false if the action naturally finishes its criteria early.
     */
    default boolean tickContinuous(Mob host) {
        execute(host);
        return true;
    }

    /**
     * Clean-up hook called when the Decision engine interrupts or switches away from this action.
     */
    default void stop(Mob host) {}
}