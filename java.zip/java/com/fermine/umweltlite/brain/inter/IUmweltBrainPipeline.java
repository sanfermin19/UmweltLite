package com.fermine.umweltlite.brain.inter;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.PolarBear;

/**
 * The unified contract governing single-class stateful cognitive pipelines.
 * Ensures data attachments, entity tick loops, and rendering shaders have standard accessors.
 */
public interface IUmweltBrainPipeline {

    /**
     * Executes the main environmental perception and action-routing loops.
     */
    void tickBrainPipeline(PolarBear bear);

    void regulate(Mob host);

    /**
     * @return Real-time adrenaline/panic register value (0.0F to 1.0F) for Red shader mapping.
     */
    float getStress();

    /**
     * @return Real-time perceptual/alertness register value (0.0F to 1.0F) for Green shader mapping.
     */
    float getStimulus();

    /**
     * @return Real-time metabolic depletion register value (0.0F to 1.0F) for Blue shader mapping.
     */
    float getFatigue();

    /**
     * @return The text representation of the current processing task to display on diagnostic screens.
     */
    String getActiveStageName();

    /**
     * Serializes internal floating registers to disk when chunks unload or worlds save.
     */
    CompoundTag serializePipeline();

    /**
     * Restores cognitive states from disk upon entity loading.
     */
    void deserializePipeline(CompoundTag tag);
}