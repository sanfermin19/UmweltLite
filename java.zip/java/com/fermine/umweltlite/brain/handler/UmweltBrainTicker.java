package com.fermine.umweltlite.brain.handler;

import com.fermine.umweltlite.UmweltLite;
import com.fermine.umweltlite.brain.capability.UmweltPipelineAttachment;
import com.fermine.umweltlite.brain.inter.IUmweltBrainPipeline;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.PolarBear;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.neoforge.attachment.AttachmentType;

@EventBusSubscriber(modid = UmweltLite.MODID)
public class UmweltBrainTicker {

    @SubscribeEvent
    public static void onMobTick(EntityTickEvent.Post event) {
        // Brain ticking operations belong purely on the server-authoritative thread context
        if (event.getEntity().level().isClientSide()) return;

        if (event.getEntity() instanceof Mob mob) {
            try {
                // Fetch the attachment type reference safely
                AttachmentType<IUmweltBrainPipeline> pipelineType = UmweltPipelineAttachment.PIPELINE_ATTACHMENT.get();

                // Defensive check: ensure the attachment registry object itself is bound and active
                if (pipelineType != null && mob.hasData(pipelineType)) {
                    IUmweltBrainPipeline pipeline = mob.getData(pipelineType);
                    pipeline.tickBrainPipeline((PolarBear) mob);
                }
            } catch (IllegalStateException e) {
                // Fallback catch block to swallow registry lookup errors gracefully during multithreaded world pre-loads
                // This keeps your developer environment from hard-crashing if world assets try ticking during dimension generation phases
            }
        }
    }
}