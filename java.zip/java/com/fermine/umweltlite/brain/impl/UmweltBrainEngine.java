package com.fermine.umweltlite.brain.impl;

import com.fermine.umweltlite.brain.inter.IUmweltBrainPipeline;
import com.fermine.umweltlite.brain.inter.IUmweltAction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Mob;
import java.util.ArrayList;
import java.util.List;

/**
 * Core framework implementation of the 5-stage cognitive pipeline.
 * Manages internal neurological registers, action arbitration, and state transitions.
 */
public abstract class UmweltBrainEngine implements IUmweltBrainPipeline {

    protected final List<IUmweltAction> actionPool = new ArrayList<>();
    protected IUmweltAction activeAction = null;

    // --- Core Neurological Registers ---
    protected float stressRegistry = 0.0f;
    protected float fatigueRegistry = 0.0f;
    protected float stimulusRegistry = 0.0f;

    /**
     * ARCHITECTURAL FIX: The strict execution driver.
     * Guarantees that no developer can accidentally misorder or skip cognitive pipeline stages.
     */
    public final void tickEnginePipeline(Mob host) {
        this.perceive(host);           // Stage 1: Sensory input collection
        this.compartmentalize(host);   // Stage 2: Affective calculation
        this.regulate(host);           // Stage 3: Biological limits/dampeners
        this.decide(host);             // Stage 4: Decision arbitration
        this.execute(host);            // Stage 5: Motor output driver
    }

    public abstract void perceive(Mob host);
    public abstract void compartmentalize(Mob host);

    public void submitActionCandidate(IUmweltAction action) {
        if (action != null) {
            this.actionPool.add(action);
        }
    }

    public void decide(Mob host) {
        if (this.actionPool.isEmpty()) {
            return;
        }

        IUmweltAction highestCandidate = null;
        float maxUrgency = -1.0f;

        for (IUmweltAction candidate : this.actionPool) {
            if (candidate.getUrgency() > maxUrgency) {
                maxUrgency = candidate.getUrgency();
                highestCandidate = candidate;
            }
        }

        if (highestCandidate != null) {
            if (this.activeAction == null) {
                this.activeAction = highestCandidate;
            } else if (!this.activeAction.getActionType().equals(highestCandidate.getActionType())) {
                // Hysteresis buffering only applies when switching to a completely different BEHAVIOR TYPE
                if (highestCandidate.getUrgency() > this.activeAction.getUrgency() + 0.15f) {
                    this.activeAction.stop(host);
                    this.activeAction = highestCandidate;
                }
            } else {
                // LOGICAL FIX: Same behavior class/type, but likely different constructor parameters
                // (e.g. a closer hunting target). We swap the reference directly as target-tracking updates,
                // but bypass hysteresis since the creature isn't changing its mind about the state.
                this.activeAction = highestCandidate;
            }
        }

        this.actionPool.clear();
    }

    public void execute(Mob host) {
        if (this.activeAction != null) {
            // FIX: Uses the correct execution method matching your Bear actions
            this.activeAction.execute(host);

            // Optional: If your IUmweltAction interface ever implements an 'isFinished(host)' check,
            // you can cleanly drop completed actions here.
        }
    }

    public IUmweltAction getActiveAction() { return this.activeAction; }
    public void setActiveAction(IUmweltAction action) { this.activeAction = action; }

    // --- Register Accessors ---
    public float getStress() { return this.stressRegistry; }
    public void setStress(float value) { this.stressRegistry = Math.max(0.0f, Math.min(1.0f, value)); }

    public float getFatigue() { return this.fatigueRegistry; }
    public void setFatigue(float value) { this.fatigueRegistry = Math.max(0.0f, Math.min(1.0f, value)); }

    public float getStimulus() { return this.stimulusRegistry; }
    public void setStimulus(float value) { this.stimulusRegistry = Math.max(0.0f, Math.min(1.0f, value)); }

    // --- NeoForge Serialization Layer ---
    @Override
    public CompoundTag serializePipeline() {
        CompoundTag tag = new CompoundTag();
        tag.putFloat("StressReg", this.stressRegistry);
        tag.putFloat("FatigueReg", this.fatigueRegistry);
        tag.putFloat("StimulusReg", this.stimulusRegistry);
        return tag;
    }

    @Override
    public void deserializePipeline(CompoundTag tag) {
        this.stressRegistry = tag.getFloat("StressReg");
        this.fatigueRegistry = tag.getFloat("FatigueReg");
        this.stimulusRegistry = tag.getFloat("StimulusReg");
    }
}