package com.fermine.umweltlite.brain.capability;

import com.fermine.umweltlite.UmweltLite;
import com.fermine.umweltlite.brain.inter.IUmweltBrainPipeline;
import com.fermine.umweltlite.example.brain.UmweltPolarBearBrain;
import net.minecraft.nbt.CompoundTag;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.attachment.IAttachmentSerializer;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;
import org.jetbrains.annotations.NotNull;
import java.util.function.Supplier;

public class UmweltPipelineAttachment {

    public static final DeferredRegister<AttachmentType<?>> ATTACHMENT_TYPES =
            DeferredRegister.create(NeoForgeRegistries.Keys.ATTACHMENT_TYPES, UmweltLite.MODID);

    public static final Supplier<AttachmentType<IUmweltBrainPipeline>> PIPELINE_ATTACHMENT = ATTACHMENT_TYPES.register(
            "brain_pipeline",
            () -> AttachmentType.builder((supplier) -> (IUmweltBrainPipeline) new UmweltPolarBearBrain())
                    .serialize(new IAttachmentSerializer<CompoundTag, IUmweltBrainPipeline>() {
                        @Override
                        public @NotNull IUmweltBrainPipeline read(net.neoforged.neoforge.attachment.@NotNull IAttachmentHolder holder, @NotNull CompoundTag nbt, net.minecraft.core.HolderLookup.@NotNull Provider provider) {
                            IUmweltBrainPipeline pipeline = new UmweltPolarBearBrain();
                            pipeline.deserializePipeline(nbt);
                            return pipeline;
                        }

                        @Override
                        public CompoundTag write(@NotNull IUmweltBrainPipeline pipeline, net.minecraft.core.HolderLookup.@NotNull Provider provider) {
                            return pipeline.serializePipeline();
                        }
                    })
                    .build()
    );
}